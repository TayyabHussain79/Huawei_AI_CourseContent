## Car Counter

* This application performs real-time vehicle detection and tracking from a video feed and aims to count the number of cars, passing on road in real time using latest version of **YOLO**, `yolo11 nano` and **OpenCV**.

* To define the region of interest, a mask is defined to the video. To ignore the cars outside road and far away on the road.

* The cars will be counted, when they reach a specific region on the road.

* The detected vehicles are tracked across frames using the `Simple online and Realtime tracking` ([SORT](https://github.com/abewley/sort)) algorithm.

* Each detected vehicle is assigned a unique ID, and the system keeps track of vehicles crossing a defined line.

* Total count of vehicles is displayed on the screen in real time.

---